DodgeBot + DodgeBot UI (R5Flowstate S30)

Install:
1. Quit the game completely.
2. Extract the whole zip to any folder (do not run it inside the zip).
3. Double-click Install.bat.
4. Start the game, host a local Dev Lab and press HOME for the settings window.

Targets page: strafer body = legend, class/legend = same as me, then spawn a strafing target.
Real fight: turn it on in the settings window (off by default, legend body only).
Update: run the new Install.bat. Uninstall: quit the game and run Uninstall.bat.

The installer copies two folders into mods, adds two lines to mods.vdf and binds HOME if it is free.
Edited files get a .bak_dodgebot backup. install.ps1 is plain text.
