DodgeBot + DodgeBot UI (R5Flowstate S30)

Install:
1. Quit the game completely.
2. Extract the whole zip to any folder (do not run it inside the zip).
3. Double-click Install.bat.
4. Start the game, host a local Dev Lab and press HOME for the settings window.

Targets: in the settings window click > under Targets and practice (legend bodies, up to 6).
God mode: the switch in the same section; it stays on after map loads.
Target armor: the row below it (white / blue / purple / red / random).
Real fight: turn it on in the settings window (off by default, legend body only).
Language: the Chinese / English button at the top right of the settings window.
Update: run the new Install.bat. Uninstall: quit the game and run Uninstall.bat.

The installer copies two folders into mods, adds two lines to mods.vdf and binds HOME if it is free.
Edited files get a .bak_dodgebot backup. install.ps1 is plain text.
