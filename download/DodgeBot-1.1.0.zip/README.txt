﻿DodgeBot + DodgeBot UI（R5Flowstate S30）

安装：
1. 完全退出游戏。
2. 把 zip 全部解压到任意文件夹（不要在压缩包里直接双击）。
3. 双击 Install.bat。
4. 启动游戏，进自己本地开的 Dev Lab，按 HOME 键打开设置窗口。

靶子页：扫射靶身体 = 传奇，职业/传奇 = 跟我一样，然后点"添加横移目标"。
真人对战：设置窗口里打开（默认关闭，只对传奇身体有效），会找掩体、滑铲跳拉出。
升级旧版：直接再运行一次 Install.bat。
卸载：退出游戏，双击 Uninstall.bat。

安装器会做的事：把两个文件夹复制到 mods，在 mods.vdf 里加两行，HOME 键空闲时绑上它。
被修改的文件旁边会留一份 .bak_dodgebot 备份。脚本是纯文本，可以用记事本打开 install.ps1 查看。
